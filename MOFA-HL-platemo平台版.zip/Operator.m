function Offspring = Operator(Population,gamma,beta0,alpha,delta,dmax,mu)
% The particle swarm optimization in MOFA-HL

%------------------------------- Copyright --------------------------------
% Copyright (c) 2021 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    P_Dec   = Population.decs;     
    [N,D]   = size(P_Dec); 
    P_Obj   = Population.objs;
    Off_P   = zeros(N,D);    
    Problem = PROBLEM.Current();
%     Off_P_Obj = zeros(N,Problem.M);    
    Lower = Problem.lower;
    Upper = Problem.upper;
    
    new_P_Dec = [];    
    [FrontNo,MaxFNo] = NDSort(P_Obj,N);
    %% Hierarchical learning
    for i = 1:MaxFNo-1               
        index_i = find(FrontNo==i); % 排名在前的个体索引
        P_Dec_p = P_Dec(index_i,:); 
%         P_Obj_p = P_Obj(index_i,:);
        
        index_j = find(FrontNo==i+1); % 排名在后的个体索引
        P_Dec_q = P_Dec(index_j,:);
        P_Obj_q = P_Obj(index_j,:);
        
        now_P_Dec_q = zeros(numel(index_j),D);
        now_P_Obj_q = zeros(numel(index_j),Problem.M);
        for q = 1 : numel(index_j)            
            rqp = zeros(1,numel(index_i));
            for p = 1: numel(index_i)
                rqp(1,p) = norm(P_Dec_p(p,:)-P_Dec_q(q,:))/dmax; % 计算吸引力                
            end            
            [R,U] = min(rqp); % 取最短距离个体
            beta1 = beta0 * exp(-gamma*R^2);
            e     = delta .* unifrnd(-1,+1,[1,D]);
            
            now_P_Dec_q(q,:) = P_Dec_q(q,:) ...
                + beta1 .* (P_Dec_p(U,:) - P_Dec_q(q,:))...
                + alpha .* e;
            
            % 限界
            now_P_Dec_q(q,:) = min(max(now_P_Dec_q(q,:),Lower),Upper);
            now_P_Obj_q(q,:) = Problem.CalObj(now_P_Dec_q(q,:));
                        
            % 支配关系
            if all(now_P_Obj_q(q,:) <= P_Obj_q(q,:)) ...
                    && any(now_P_Obj_q(q,:)  < P_Obj_q(q,:))
                P_Dec_q(q,:) = now_P_Dec_q(q,:);
            end
        end               
        new_P_Dec = [new_P_Dec;P_Dec_q];
    end
    
    % 第一前沿变异
    index_1 = FrontNo == 1; % 排名在第1的个体索引
    P_Dec_first_front = P_Dec(index_1,:);
    Off_P = [P_Dec_first_front;new_P_Dec];

    %领域变异
%     Population = DE_mu_cr_operator(Population(:,1: V+M),M,V, Cr, F,VarMin,VarMax);
%     Population = PolynomialMutation(Population,VarMax,VarMin);
    Off_P = Mutate(Off_P,mu,D,Lower,Upper);
    
	Offspring = SOLUTION(Off_P);
end