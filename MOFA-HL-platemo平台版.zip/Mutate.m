%% ʵ������
function y = Mutate(x,mu,D,VarMin,VarMax)

%% Problem Definition  ���ⶨ��
% CostFunction=@(p) ZDT2(p);        % Cost Function

[N,~] = size(x);
y = zeros(N,D);
for i = 1:N
    nmu=ceil(mu*D);
    
    j=randi([1 D],1,nmu); %�������1-V֮�����nmu��
    sigma=0.2 .* (VarMax(j)-VarMin(j));
    
    y(i,1:D)=x(i,1:D);
    y(i,j)=x(i,j)+ sigma .* randn(size(j));
    
    y=min(max(y,VarMin),VarMax);

%     y(i,V + 1: V+M) = CostFunction(y(i,1:V));
%     % ֧���ϵ
%     if all(y(i,V+1:V+M) <= x(i,V+1:V+M))...
%             && any(y(i,V+1:V+M) <= x(i,V+1:V+M))
%         x(i,1:V+M) = y(i,1:V+M);
%     end
end

