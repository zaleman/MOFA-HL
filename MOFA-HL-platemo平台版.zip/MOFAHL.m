classdef MOFAHL < ALGORITHM
% <multi> <real>
% Multi-objective firefly algorithm with hierarchical learning
% gamma  --- 1 ---       Light Absorption Coefficient
% beta0  --- 1 ---       Attraction Coefficient Base Value
% alpha  --- 0.2 ---     Mutation Coefficient
% alpha_damp --- 0.9 --- Mutation Coefficient Damping Ratio
% mu     --- 0.1---      Mutation Rate

%------------------------------- Reference --------------------------------
% X. S. Yang. Multi-objective Firefly Algorithm for Continuous 
% Optimization[J]. Engineering With Computers, 2013, 29(2): 175-184.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2021 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    methods
        function main(Algorithm,Problem)
            %% Generate random population
            [gamma,beta0,alpha,alpha_damp,mu]= Algorithm.ParameterSet(1,1,0.2,0.9,0.1);
            Population = Problem.Initialization();
            Problem = PROBLEM.Current();
            delta   = 0.5 * (Problem.upper-Problem.lower); % Uniform Mutation Range
            
            if isscalar(Problem.lower) && isscalar(Problem.upper)
                dmax = (Problem.upper-Problem.lower)*sqrt(D);
            else
                dmax = norm(Problem.upper-Problem.lower);
            end
            
            
            %% Optimization
            while Algorithm.NotTerminated(Population)                
                Offspring  = Operator(Population,gamma,beta0,alpha,delta,dmax,mu);

                Population = EnvironmentalSelection([Population,Offspring],Problem.N);
                alpha = alpha * alpha_damp;
            end
        end
    end
end